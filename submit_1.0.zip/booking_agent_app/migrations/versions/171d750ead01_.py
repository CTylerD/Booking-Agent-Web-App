"""empty message

Revision ID: 171d750ead01
Revises: 
Create Date: 2020-02-29 18:41:52.971659

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '171d750ead01'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
